
from django.shortcuts import render,redirect
from .models import Student,Prediction

def home(request):
    return render(request,'home.html')

def register(request):
    if request.method=='POST':
        Student.objects.create(name=request.POST['name'],email=request.POST['email'],age=request.POST['age'],marks=request.POST['marks'])
        return redirect('students_list')
    return render(request,'register.html')

def students_list(request):
    data=Student.objects.all()
    return render(request,'students_list.html',{'data':data})

def predict(request):
    if request.method=='POST':
        student=Student.objects.get(id=request.POST['student'])
        result="Pass" if student.marks>40 else "Fail"
        Prediction.objects.create(student=student,result=result)
        return redirect('predictions')
    students=Student.objects.all()
    return render(request,'predict.html',{'students':students})

def predictions(request):
    data=Prediction.objects.all()
    return render(request,'predictions.html',{'data':data})
