
from django.contrib import admin
from .models import Student, Prediction
admin.site.register(Student)
admin.site.register(Prediction)
