
from django.db import models
class Student(models.Model):
    name=models.CharField(max_length=100)
    email=models.EmailField()
    age=models.IntegerField()
    marks=models.IntegerField()
class Prediction(models.Model):
    student=models.ForeignKey(Student,on_delete=models.CASCADE)
    result=models.CharField(max_length=100)
